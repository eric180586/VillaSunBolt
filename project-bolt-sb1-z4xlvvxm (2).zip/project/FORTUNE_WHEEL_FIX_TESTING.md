# 🎰 Fortune Wheel - Fix Documentation & Testing

## 🐛 PROBLEME IDENTIFIZIERT:

### Problem 1: Mehrfaches Drehen pro Person ❌
**Ursache**: Race Conditions im Frontend
- `checkForMissedFortuneWheel()` - beim Laden der Komponente
- Realtime-Listener - bei approval notification
- `handleCheckIn()` - direkt nach check-in
- Alle drei können **gleichzeitig** laufen und das Wheel öffnen

**Symptom**: User sieht Glücksrad mehrmals, kann mehrmals drehen

### Problem 2: Punkte werden nicht gutgeschrieben ❌
**Ursache**: Verwendung von `actualPoints` statt konsistente Punktevergabe
- Glücksrad zeigt `rewardValue` (1, 5, 10)
- Code verwendet aber `actualPoints` (-4, 0, 5)
- Verwirrend und inkonsistent

**Symptom**: Punkte erscheinen nicht in der Punkteübersicht

---

## ✅ LÖSUNG IMPLEMENTIERT:

### Fix 1: Race Condition Prevention

**Neue State Variable:**
```typescript
const [isCheckingWheel, setIsCheckingWheel] = useState(false);
```

**Verbesserungen:**

1. **Mutex-Lock Pattern**:
   - `isCheckingWheel` verhindert parallele Checks
   - Alle 3 Check-Funktionen prüfen dieses Flag

2. **Datenbank als Single Source of Truth**:
   - LocalStorage wurde entfernt (war unreliable)
   - Jeder Check fragt DB: "Hat User heute schon gedreht?"
   - DB UNIQUE constraint verhindert doppelte Einträge

3. **Zusätzliche Guards**:
   ```typescript
   if (hasSpun || showFortuneWheel) return; // Doppel-Check
   ```

### Fix 2: Konsistente Punktevergabe

**Vorher:**
```typescript
if (segment.actualPoints !== 0) {
  // Problem: actualPoints war -4, 0, oder 5
  // Aber angezeigt wurde rewardValue (1, 5, 10)
}
```

**Nachher:**
```typescript
// Klare Logs
console.log('Fortune Wheel Complete:', {
  segment: segment,
  actualPoints: segment.actualPoints  // Was WIRKLICH geändert wird
});

// Gleiche Logik, aber bessere Logs
if (segment.actualPoints !== 0) {
  const { data, error } = await supabase.rpc('add_bonus_points', {
    p_user_id: profile.id,
    p_points: segment.actualPoints,
    p_reason: `Glücksrad: ${segment.label}`
  });

  console.log('Bonus points added:', data);
}
```

**Wichtig**: `actualPoints` ist das korrekte Feld!
- Segment 1: rewardValue=1, actualPoints=-4 (Malus!)
- Segment 2-9: rewardValue=5, actualPoints=0 (keine Änderung)
- Segment 10: rewardValue=10, actualPoints=5 (Bonus!)

---

## 🧪 TESTING GUIDE

### Test 1: Überprüfe aktuelle Daten

```sql
-- Check heute's fortune wheel spins
SELECT
  p.full_name,
  p.role,
  fws.spin_date,
  fws.reward_label,
  fws.reward_value,
  fws.created_at,
  ci.check_in_time,
  ci.status as check_in_status
FROM fortune_wheel_spins fws
JOIN profiles p ON fws.user_id = p.id
LEFT JOIN check_ins ci ON fws.check_in_id = ci.id
WHERE fws.spin_date = CURRENT_DATE
ORDER BY fws.created_at DESC;
```

**Erwartung**:
- Jeder User max. 1 Eintrag pro Tag
- Wenn mehrere → Bug bestätigt

### Test 2: Überprüfe Punkte-Historie

```sql
-- Check ob Glücksrad-Punkte eingetragen wurden
SELECT
  ph.user_id,
  p.full_name,
  ph.points_change,
  ph.reason,
  ph.category,
  ph.created_at,
  ph.created_by
FROM points_history ph
JOIN profiles p ON ph.user_id = p.id
WHERE ph.reason LIKE '%Glücksrad%'
  OR ph.reason LIKE '%Fortune%'
  OR ph.category = 'bonus'
ORDER BY ph.created_at DESC
LIMIT 20;
```

**Erwartung**:
- Entries mit `category = 'bonus'`
- `points_change` sollte `-4`, `0`, oder `5` sein
- `reason` enthält "Glücksrad"

### Test 3: Check Daily Point Goals Update

```sql
-- Verify points were added to daily totals
SELECT
  p.full_name,
  dpg.goal_date,
  dpg.achieved_points,
  dpg.theoretically_achievable_points,
  dpg.percentage,
  dpg.updated_at
FROM daily_point_goals dpg
JOIN profiles p ON dpg.user_id = p.id
WHERE dpg.goal_date = CURRENT_DATE
ORDER BY dpg.updated_at DESC;
```

**Erwartung**:
- `achieved_points` wurde aktualisiert nach Spin
- `updated_at` timestamp passt zu Spin-Zeit

### Test 4: Duplikate finden

```sql
-- Find users with multiple spins same day
SELECT
  user_id,
  spin_date,
  COUNT(*) as spin_count,
  array_agg(reward_label ORDER BY created_at) as rewards,
  array_agg(created_at ORDER BY created_at) as timestamps
FROM fortune_wheel_spins
GROUP BY user_id, spin_date
HAVING COUNT(*) > 1
ORDER BY spin_date DESC, spin_count DESC;
```

**Erwartung nach Fix**:
- Leere Ergebnismenge
- Wenn Einträge → noch Duplikate vorhanden

### Test 5: Clean-Up Duplikate (falls vorhanden)

```sql
-- DELETE duplicates, keep oldest
WITH ranked_spins AS (
  SELECT
    id,
    ROW_NUMBER() OVER (
      PARTITION BY user_id, spin_date
      ORDER BY created_at ASC
    ) as rn
  FROM fortune_wheel_spins
)
DELETE FROM fortune_wheel_spins
WHERE id IN (
  SELECT id FROM ranked_spins WHERE rn > 1
);

-- Check how many deleted
SELECT
  'Deleted ' || COUNT(*) || ' duplicate spins' as result
FROM ranked_spins
WHERE rn > 1;
```

**ACHTUNG**: Nur ausführen wenn Test 4 Duplikate zeigt!

---

## 🎬 LIVE TEST PROCEDURE

### Vorbereitung:

1. **Browser Console öffnen** (F12)
2. **SQL Editor in Supabase bereit halten**
3. **Test-User einloggen** (kein Admin!)

### Test-Ablauf:

#### Schritt 1: Baseline Check
```sql
-- Vor dem Test: Aktuellen Stand notieren
SELECT * FROM fortune_wheel_spins
WHERE user_id = '<test_user_id>'
AND spin_date = CURRENT_DATE;

SELECT achieved_points FROM daily_point_goals
WHERE user_id = '<test_user_id>'
AND goal_date = CURRENT_DATE;
```

#### Schritt 2: Check-In durchführen
1. App öffnen → Check-In Page
2. "Früh" oder "Spät" Check-In klicken
3. **Browser Console beobachten** - achten auf:
   ```
   "Checking fortune wheel for user..."
   "Already spun? false"
   "No spin found, showing fortune wheel IMMEDIATELY"
   ```

#### Schritt 3: Als Admin approven
1. Als Admin einloggen
2. Check-In Approval Page öffnen
3. Check-In approven
4. **Zurück zum Test-User Browser**

#### Schritt 4: Glücksrad testen
**Browser Console sollte zeigen:**
```
"Realtime: Check-in approved! ID: xxx"
"Realtime: Already spun? false"
"Realtime: Opening Fortune Wheel NOW!"
```

**Erwartung:**
- ✅ Glücksrad öffnet sich **EINMAL**
- ✅ User kann drehen
- ✅ Ergebnis wird angezeigt

**Was NICHT passieren darf:**
- ❌ Glücksrad öffnet zweimal
- ❌ "Already checking" Meldung in Console

#### Schritt 5: Punkte überprüfen

**Console sollte zeigen:**
```javascript
"Fortune Wheel Complete: {
  user_id: '...',
  segment: {...},
  actualPoints: 5  // oder -4, oder 0
}"
"Spin saved successfully"
"Adding bonus points: 5"  // oder "-4" oder "No bonus points (0)"
"Bonus points added successfully"
```

**SQL Check:**
```sql
-- Spin wurde gespeichert?
SELECT * FROM fortune_wheel_spins
WHERE user_id = '<test_user_id>'
AND spin_date = CURRENT_DATE;

-- Punkte in Historie?
SELECT * FROM points_history
WHERE user_id = '<test_user_id>'
AND category = 'bonus'
ORDER BY created_at DESC LIMIT 1;

-- Daily Goals updated?
SELECT achieved_points FROM daily_point_goals
WHERE user_id = '<test_user_id>'
AND goal_date = CURRENT_DATE;
```

**Erwartung:**
- ✅ Genau 1 Eintrag in `fortune_wheel_spins`
- ✅ 1 neuer Eintrag in `points_history` (wenn actualPoints ≠ 0)
- ✅ `achieved_points` korrekt aktualisiert

#### Schritt 6: Doppel-Spin verhindern testen

**App neu laden (F5)**

**Console sollte zeigen:**
```
"checkIfAlreadySpunToday: Already spun? true"
"checkForMissedFortuneWheel: Already spun today, skipping"
```

**Erwartung:**
- ✅ Glücksrad öffnet sich **NICHT**
- ✅ Kein Button zum erneuten Drehen
- ✅ Console zeigt "already spun"

#### Schritt 7: Zweiten Check-In verhindern

**Nochmal Check-In klicken**

**Erwartung:**
- ✅ Error: "Already checked in today" ODER
- ✅ Glücksrad öffnet nicht (da schon gedreht)

---

## 📊 ERFOLGS-KRITERIEN

### ✅ Test erfolgreich wenn:

1. **Kein Doppel-Spin**:
   - User sieht Glücksrad max. 1x pro Tag
   - SQL zeigt max. 1 Eintrag pro User pro Tag
   - Console zeigt "already spun" bei zweitem Versuch

2. **Punkte werden gutgeschrieben**:
   - `points_history` Eintrag existiert
   - `daily_point_goals` wurde aktualisiert
   - Frontend zeigt neue Punkte-Anzahl

3. **Keine Race Conditions**:
   - Console zeigt "already checking" bei parallelen Requests
   - `isCheckingWheel` Flag funktioniert
   - Keine parallelen Wheel-Öffnungen

4. **Korrekte Punkte-Werte**:
   - Segment 1 (-4 Punkte): Punktzahl SINKT
   - Segment 2-9 (0 Punkte): Punktzahl GLEICH
   - Segment 10 (+5 Punkte): Punktzahl STEIGT

---

## 🔧 TROUBLESHOOTING

### Problem: Glücksrad öffnet immer noch mehrfach

**Check:**
```sql
-- Sind doppelte Spins in DB?
SELECT user_id, spin_date, COUNT(*)
FROM fortune_wheel_spins
GROUP BY user_id, spin_date
HAVING COUNT(*) > 1;
```

**Fix**: Clean-Up Script (siehe Test 5) ausführen

### Problem: Punkte werden immer noch nicht gutgeschrieben

**Check Console:**
- Zeigt "Adding bonus points"?
- Error bei `add_bonus_points` RPC?

**Check DB:**
```sql
-- Existiert add_bonus_points function?
SELECT proname, prosrc
FROM pg_proc
WHERE proname = 'add_bonus_points';

-- Test function direkt:
SELECT add_bonus_points(
  '<user_id>'::uuid,
  5,
  'Test Fortune Wheel'
);
```

### Problem: "Already checking" Loop

**Fix**: Browser refresh
- State wird zurückgesetzt
- `isCheckingWheel` = false

---

## 📝 CHANGELOG

### Änderungen in CheckIn.tsx:

1. **Added State**:
   - `isCheckingWheel` - Race condition prevention

2. **Modified Functions**:
   - `checkIfAlreadySpunToday()` - Returns boolean, no localStorage
   - `checkForMissedFortuneWheel()` - Uses mutex lock
   - Realtime listener - Uses mutex lock
   - `handleCheckIn()` - Uses mutex lock
   - `handleFortuneWheelComplete()` - Better logging, double-check before insert

3. **Removed**:
   - localStorage for wheel spins (unreliable)

4. **Added Guards**:
   - `if (isCheckingWheel) return;` - in allen check functions
   - `if (showFortuneWheel) return;` - prevent opening twice
   - `await checkIfAlreadySpunToday()` - before showing wheel

---

## ✅ READY FOR TESTING

Das System ist jetzt bereit für Live-Tests!

**Empfohlene Reihenfolge:**
1. SQL Tests 1-4 ausführen (Status quo)
2. Falls Duplikate: Clean-Up (Test 5)
3. Live Test durchführen (alle Schritte)
4. Nochmal SQL Tests (Verifizierung)

**Bei Erfolg:**
- ✅ Deployment ready
- ✅ Dokumentation komplett
- ✅ Keine bekannten Bugs

**Bei Problemen:**
- Console Logs analysieren
- SQL Queries zur Diagnose
- Troubleshooting Section nutzen
