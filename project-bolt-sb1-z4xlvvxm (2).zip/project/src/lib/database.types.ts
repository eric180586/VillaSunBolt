export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string
          role: 'admin' | 'manager' | 'staff'
          avatar_url: string | null
          total_points: number
          preferred_language: 'de' | 'en' | 'km'
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name: string
          role?: 'admin' | 'manager' | 'staff'
          avatar_url?: string | null
          total_points?: number
          preferred_language?: 'de' | 'en' | 'km'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          role?: 'admin' | 'manager' | 'staff'
          avatar_url?: string | null
          total_points?: number
          preferred_language?: 'de' | 'en' | 'km'
          created_at?: string
          updated_at?: string
        }
      }
      check_ins: {
        Row: {
          id: string
          user_id: string
          check_in_time: string
          shift_type: string
          is_late: boolean | null
          minutes_late: number | null
          points_awarded: number | null
          created_at: string | null
          status: string | null
          approved_by: string | null
          approved_at: string | null
          checkout_time: string | null
          work_hours: number | null
          late_reason: string | null
        }
        Insert: {
          id?: string
          user_id: string
          check_in_time?: string
          shift_type: string
          is_late?: boolean | null
          minutes_late?: number | null
          points_awarded?: number | null
          created_at?: string | null
          status?: string | null
          approved_by?: string | null
          approved_at?: string | null
          checkout_time?: string | null
          work_hours?: number | null
          late_reason?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          check_in_time?: string
          shift_type?: string
          is_late?: boolean | null
          minutes_late?: number | null
          points_awarded?: number | null
          created_at?: string | null
          status?: string | null
          approved_by?: string | null
          approved_at?: string | null
          checkout_time?: string | null
          work_hours?: number | null
          late_reason?: string | null
        }
      }
      checklist_instances: {
        Row: {
          id: string
          checklist_id: string
          instance_date: string
          items: Json
          status: string | null
          completed_by: string | null
          completed_at: string | null
          points_awarded: boolean | null
          created_at: string | null
          updated_at: string | null
          photo_proof: string | null
          photo_required_for_completion: boolean | null
          admin_reviewed: boolean | null
          admin_approved: boolean | null
          admin_rejection_reason: string | null
          reviewed_by: string | null
          reviewed_at: string | null
          admin_photo: string | null
        }
        Insert: {
          id?: string
          checklist_id: string
          instance_date: string
          items: Json
          status?: string | null
          completed_by?: string | null
          completed_at?: string | null
          points_awarded?: boolean | null
          created_at?: string | null
          updated_at?: string | null
          photo_proof?: string | null
          photo_required_for_completion?: boolean | null
          admin_reviewed?: boolean | null
          admin_approved?: boolean | null
          admin_rejection_reason?: string | null
          reviewed_by?: string | null
          reviewed_at?: string | null
          admin_photo?: string | null
        }
        Update: {
          id?: string
          checklist_id?: string
          instance_date?: string
          items?: Json
          status?: string | null
          completed_by?: string | null
          completed_at?: string | null
          points_awarded?: boolean | null
          created_at?: string | null
          updated_at?: string | null
          photo_proof?: string | null
          photo_required_for_completion?: boolean | null
          admin_reviewed?: boolean | null
          admin_approved?: boolean | null
          admin_rejection_reason?: string | null
          reviewed_by?: string | null
          reviewed_at?: string | null
          admin_photo?: string | null
        }
      }
      weekly_schedules: {
        Row: {
          id: string
          staff_id: string
          week_start_date: string
          shifts: Json
          is_published: boolean | null
          created_by: string | null
          published_at: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          staff_id: string
          week_start_date: string
          shifts?: Json
          is_published?: boolean | null
          created_by?: string | null
          published_at?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          staff_id?: string
          week_start_date?: string
          shifts?: Json
          is_published?: boolean | null
          created_by?: string | null
          published_at?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      chat_messages: {
        Row: {
          id: string
          user_id: string
          message: string
          message_de: string | null
          message_km: string | null
          photo_url: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          user_id: string
          message: string
          message_de?: string | null
          message_km?: string | null
          photo_url?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          message?: string
          message_de?: string | null
          message_km?: string | null
          photo_url?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      fortune_wheel_spins: {
        Row: {
          id: string
          user_id: string
          check_in_id: string
          spin_date: string
          reward_type: string
          reward_value: number
          reward_label: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          check_in_id: string
          spin_date?: string
          reward_type: string
          reward_value?: number
          reward_label: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          check_in_id?: string
          spin_date?: string
          reward_type?: string
          reward_value?: number
          reward_label?: string
          created_at?: string
        }
      }
      push_subscriptions: {
        Row: {
          id: string
          user_id: string
          endpoint: string
          p256dh: string
          auth: string
          user_agent: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          user_id: string
          endpoint: string
          p256dh: string
          auth: string
          user_agent?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          endpoint?: string
          p256dh?: string
          auth?: string
          user_agent?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      shopping_items: {
        Row: {
          id: string
          item_name: string
          description: string | null
          photo_url: string | null
          is_purchased: boolean | null
          created_by: string | null
          purchased_by: string | null
          created_at: string | null
          purchased_at: string | null
        }
        Insert: {
          id?: string
          item_name: string
          description?: string | null
          photo_url?: string | null
          is_purchased?: boolean | null
          created_by?: string | null
          purchased_by?: string | null
          created_at?: string | null
          purchased_at?: string | null
        }
        Update: {
          id?: string
          item_name?: string
          description?: string | null
          photo_url?: string | null
          is_purchased?: boolean | null
          created_by?: string | null
          purchased_by?: string | null
          created_at?: string | null
          purchased_at?: string | null
        }
      }
      patrol_rounds: {
        Row: {
          id: string
          date: string
          time_slot: string
          assigned_to: string | null
          completed_at: string | null
          created_at: string | null
          points_awarded: number | null
          points_calculated: boolean | null
          notification_sent: boolean | null
          scheduled_time: string | null
        }
        Insert: {
          id?: string
          date: string
          time_slot: string
          assigned_to?: string | null
          completed_at?: string | null
          created_at?: string | null
          points_awarded?: number | null
          points_calculated?: boolean | null
          notification_sent?: boolean | null
          scheduled_time?: string | null
        }
        Update: {
          id?: string
          date?: string
          time_slot?: string
          assigned_to?: string | null
          completed_at?: string | null
          created_at?: string | null
          points_awarded?: number | null
          points_calculated?: boolean | null
          notification_sent?: boolean | null
          scheduled_time?: string | null
        }
      }
      patrol_locations: {
        Row: {
          id: string
          name: string
          qr_code: string
          description: string
          order_index: number
          created_at: string | null
          photo_explanation: string | null
        }
        Insert: {
          id?: string
          name: string
          qr_code: string
          description: string
          order_index: number
          created_at?: string | null
          photo_explanation?: string | null
        }
        Update: {
          id?: string
          name?: string
          qr_code?: string
          description?: string
          order_index?: number
          created_at?: string | null
          photo_explanation?: string | null
        }
      }
      patrol_scans: {
        Row: {
          id: string
          patrol_round_id: string | null
          location_id: string | null
          user_id: string | null
          scanned_at: string | null
          photo_url: string | null
          photo_requested: boolean | null
          created_at: string | null
        }
        Insert: {
          id?: string
          patrol_round_id?: string | null
          location_id?: string | null
          user_id?: string | null
          scanned_at?: string | null
          photo_url?: string | null
          photo_requested?: boolean | null
          created_at?: string | null
        }
        Update: {
          id?: string
          patrol_round_id?: string | null
          location_id?: string | null
          user_id?: string | null
          scanned_at?: string | null
          photo_url?: string | null
          photo_requested?: boolean | null
          created_at?: string | null
        }
      }
      patrol_schedules: {
        Row: {
          id: string
          date: string
          shift: string
          assigned_to: string | null
          created_by: string | null
          created_at: string | null
        }
        Insert: {
          id?: string
          date: string
          shift: string
          assigned_to?: string | null
          created_by?: string | null
          created_at?: string | null
        }
        Update: {
          id?: string
          date?: string
          shift?: string
          assigned_to?: string | null
          created_by?: string | null
          created_at?: string | null
        }
      }
      how_to_documents: {
        Row: {
          id: string
          title: string
          description: string | null
          file_url: string
          file_type: string
          file_name: string
          file_size: number | null
          category: string | null
          sort_order: number | null
          created_by: string
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          file_url: string
          file_type: string
          file_name: string
          file_size?: number | null
          category?: string | null
          sort_order?: number | null
          created_by: string
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          file_url?: string
          file_type?: string
          file_name?: string
          file_size?: number | null
          category?: string | null
          sort_order?: number | null
          created_by?: string
          created_at?: string | null
          updated_at?: string | null
        }
      }
      humor_modules: {
        Row: {
          id: string
          name: string
          label: string
          percentage: number
          is_active: boolean | null
          sort_order: number | null
          icon_name: string | null
          color_class: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          name: string
          label: string
          percentage?: number
          is_active?: boolean | null
          sort_order?: number | null
          icon_name?: string | null
          color_class?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          name?: string
          label?: string
          percentage?: number
          is_active?: boolean | null
          sort_order?: number | null
          icon_name?: string | null
          color_class?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      humor_sections: {
        Row: {
          id: string
          title: string
          percentage: number
          icon_name: string
          color: string
          is_active: boolean | null
          order_index: number | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          title: string
          percentage: number
          icon_name?: string
          color?: string
          is_active?: boolean | null
          order_index?: number | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          title?: string
          percentage?: number
          icon_name?: string
          color?: string
          is_active?: boolean | null
          order_index?: number | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      point_templates: {
        Row: {
          id: string
          name: string
          points: number
          reason: string
          category: string | null
          created_by: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          name: string
          points: number
          reason: string
          category?: string | null
          created_by?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          name?: string
          points?: number
          reason?: string
          category?: string | null
          created_by?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      motivational_messages: {
        Row: {
          id: string
          message: string
          category: string | null
          is_active: boolean | null
          created_at: string | null
        }
        Insert: {
          id?: string
          message: string
          category?: string | null
          is_active?: boolean | null
          created_at?: string | null
        }
        Update: {
          id?: string
          message?: string
          category?: string | null
          is_active?: boolean | null
          created_at?: string | null
        }
      }
      user_daily_task_counts: {
        Row: {
          id: string
          user_id: string
          count_date: string
          total_tasks: number | null
          completed_tasks: number | null
          created_at: string | null
        }
        Insert: {
          id?: string
          user_id: string
          count_date?: string
          total_tasks?: number | null
          completed_tasks?: number | null
          created_at?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          count_date?: string
          total_tasks?: number | null
          completed_tasks?: number | null
          created_at?: string | null
        }
      }
      team_daily_totals: {
        Row: {
          id: string
          date: string
          total_tasks: number | null
          completed_tasks: number | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          date: string
          total_tasks?: number | null
          completed_tasks?: number | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          date?: string
          total_tasks?: number | null
          completed_tasks?: number | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      time_off_requests: {
        Row: {
          id: string
          staff_id: string
          request_date: string
          reason: string
          status: string | null
          admin_response: string | null
          reviewed_by: string | null
          reviewed_at: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          staff_id: string
          request_date: string
          reason: string
          status?: string | null
          admin_response?: string | null
          reviewed_by?: string | null
          reviewed_at?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          staff_id?: string
          request_date?: string
          reason?: string
          status?: string | null
          admin_response?: string | null
          reviewed_by?: string | null
          reviewed_at?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      notification_preferences: {
        Row: {
          user_id: string
          check_in_request: boolean | null
          check_in_approved: boolean | null
          check_in_rejected: boolean | null
          task_assigned: boolean | null
          task_approved: boolean | null
          checklist_approved: boolean | null
          checklist_rejected: boolean | null
          reception_note: boolean | null
          departure_request: boolean | null
          all_notifications: boolean | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          user_id: string
          check_in_request?: boolean | null
          check_in_approved?: boolean | null
          check_in_rejected?: boolean | null
          task_assigned?: boolean | null
          task_approved?: boolean | null
          checklist_approved?: boolean | null
          checklist_rejected?: boolean | null
          reception_note?: boolean | null
          departure_request?: boolean | null
          all_notifications?: boolean | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          user_id?: string
          check_in_request?: boolean | null
          check_in_approved?: boolean | null
          check_in_rejected?: boolean | null
          task_assigned?: boolean | null
          task_approved?: boolean | null
          checklist_approved?: boolean | null
          checklist_rejected?: boolean | null
          reception_note?: boolean | null
          departure_request?: boolean | null
          all_notifications?: boolean | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      schedules: {
        Row: {
          id: string
          staff_id: string | null
          title: string
          start_time: string
          end_time: string
          location: string | null
          notes: string | null
          color: string
          created_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          staff_id?: string | null
          title: string
          start_time: string
          end_time: string
          location?: string | null
          notes?: string | null
          color?: string
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          staff_id?: string | null
          title?: string
          start_time?: string
          end_time?: string
          location?: string | null
          notes?: string | null
          color?: string
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      tasks: {
        Row: {
          id: string
          category: string
          title: string
          description: string | null
          assigned_to: string | null
          secondary_assigned_to: string | null
          created_by: string | null
          status: 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'pending_review' | 'archived'
          priority: 'low' | 'medium' | 'high' | 'urgent'
          due_date: string | null
          duration_minutes: number
          points_value: number
          photo_explanation: string | null
          photo_proof_required: boolean
          photo_proof: string | null
          completion_notes: string | null
          admin_notes: string | null
          admin_photo: string | null
          reopened_count: number
          completed_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          category: string
          title: string
          description?: string | null
          assigned_to?: string | null
          secondary_assigned_to?: string | null
          created_by?: string | null
          status?: 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'pending_review' | 'archived'
          priority?: 'low' | 'medium' | 'high' | 'urgent'
          due_date?: string | null
          duration_minutes?: number
          points_value?: number
          photo_explanation?: string | null
          photo_proof_required?: boolean
          photo_proof?: string | null
          completion_notes?: string | null
          admin_notes?: string | null
          admin_photo?: string | null
          reopened_count?: number
          completed_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          category?: string
          title?: string
          description?: string | null
          assigned_to?: string | null
          secondary_assigned_to?: string | null
          created_by?: string | null
          status?: 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'pending_review' | 'archived'
          priority?: 'low' | 'medium' | 'high' | 'urgent'
          due_date?: string | null
          duration_minutes?: number
          points_value?: number
          photo_explanation?: string | null
          photo_proof_required?: boolean
          photo_proof?: string | null
          completion_notes?: string | null
          admin_notes?: string | null
          admin_photo?: string | null
          reopened_count?: number
          completed_at?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      checklists: {
        Row: {
          id: string
          title: string
          description: string | null
          items: string[]
          category: string
          due_date: string | null
          due_time: string | null
          points_value: number
          recurrence: string
          duration_minutes: number
          photo_required: boolean
          photo_required_sometimes: boolean
          description_photo: string | null
          explanation_photo: string | null
          created_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          items?: string[]
          category?: string
          due_date?: string | null
          due_time?: string | null
          points_value?: number
          recurrence?: string
          duration_minutes?: number
          photo_required?: boolean
          photo_required_sometimes?: boolean
          description_photo?: string | null
          explanation_photo?: string | null
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          items?: string[]
          category?: string
          due_date?: string | null
          due_time?: string | null
          points_value?: number
          recurrence?: string
          duration_minutes?: number
          photo_required?: boolean
          photo_required_sometimes?: boolean
          description_photo?: string | null
          explanation_photo?: string | null
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      checklist_items: {
        Row: {
          id: string
          checklist_id: string
          title: string
          description: string | null
          order_index: number
          is_completed: boolean
          completed_by: string | null
          completed_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          checklist_id: string
          title: string
          description?: string | null
          order_index?: number
          is_completed?: boolean
          completed_by?: string | null
          completed_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          checklist_id?: string
          title?: string
          description?: string | null
          order_index?: number
          is_completed?: boolean
          completed_by?: string | null
          completed_at?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      notes: {
        Row: {
          id: string
          title: string
          content: string
          category: string
          is_important: boolean
          created_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          content: string
          category?: string
          is_important?: boolean
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          content?: string
          category?: string
          is_important?: boolean
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      points_history: {
        Row: {
          id: string
          user_id: string
          points_change: number
          reason: string
          category: 'task_completed' | 'bonus' | 'deduction' | 'achievement' | 'other'
          created_by: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          points_change: number
          reason: string
          category?: 'task_completed' | 'bonus' | 'deduction' | 'achievement' | 'other'
          created_by?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          points_change?: number
          reason?: string
          category?: 'task_completed' | 'bonus' | 'deduction' | 'achievement' | 'other'
          created_by?: string | null
          created_at?: string
        }
      }
      notifications: {
        Row: {
          id: string
          user_id: string
          title: string
          message: string
          type: string
          is_read: boolean
          link: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          message: string
          type?: string
          is_read?: boolean
          link?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          message?: string
          type?: string
          is_read?: boolean
          link?: string | null
          created_at?: string
        }
      }
      departure_requests: {
        Row: {
          id: string
          user_id: string
          shift_date: string
          shift_type: 'früh' | 'spät'
          request_time: string
          status: 'pending' | 'approved' | 'rejected'
          admin_id: string | null
          admin_notes: string | null
          processed_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          shift_date: string
          shift_type: 'früh' | 'spät'
          request_time?: string
          status?: 'pending' | 'approved' | 'rejected'
          admin_id?: string | null
          admin_notes?: string | null
          processed_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          shift_date?: string
          shift_type?: 'früh' | 'spät'
          request_time?: string
          status?: 'pending' | 'approved' | 'rejected'
          admin_id?: string | null
          admin_notes?: string | null
          processed_at?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      notification_read_receipts: {
        Row: {
          id: string
          notification_id: string
          user_id: string
          read_at: string
          created_at: string
        }
        Insert: {
          id?: string
          notification_id: string
          user_id: string
          read_at?: string
          created_at?: string
        }
        Update: {
          id?: string
          notification_id?: string
          user_id?: string
          read_at?: string
          created_at?: string
        }
      }
      daily_point_goals: {
        Row: {
          id: string
          user_id: string
          goal_date: string
          theoretically_achievable_points: number
          achieved_points: number
          percentage: number
          color_status: 'red' | 'yellow' | 'orange' | 'green' | 'dark_green' | 'gray'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          goal_date?: string
          theoretically_achievable_points?: number
          achieved_points?: number
          percentage?: number
          color_status?: 'red' | 'yellow' | 'orange' | 'green' | 'dark_green' | 'gray'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          goal_date?: string
          theoretically_achievable_points?: number
          achieved_points?: number
          percentage?: number
          color_status?: 'red' | 'yellow' | 'orange' | 'green' | 'dark_green' | 'gray'
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      process_check_in: {
        Args: {
          p_user_id: string
          p_shift_type?: string
          p_late_reason?: string
        }
        Returns: Json
      }
      approve_checklist_instance: {
        Args: {
          p_instance_id: string
          p_admin_id: string
        }
        Returns: Json
      }
      approve_checklist_with_points: {
        Args: {
          p_instance_id: string
          p_admin_id: string
        }
        Returns: Json
      }
      reject_checklist_instance: {
        Args: {
          p_instance_id: string
          p_admin_id: string
          p_rejection_reason: string
        }
        Returns: Json
      }
      approve_check_in: {
        Args: {
          p_check_in_id: string
          p_admin_id: string
          p_custom_points?: number
        }
        Returns: Json
      }
      reject_check_in: {
        Args: {
          p_check_in_id: string
          p_admin_id: string
          p_reason: string
        }
        Returns: Json
      }
      add_bonus_points: {
        Args: {
          p_user_id: string
          p_points: number
          p_reason: string
        }
        Returns: void
      }
      complete_patrol_round: {
        Args: {
          p_round_id: string
        }
        Returns: Json
      }
      generate_due_checklists: {
        Args: Record<string, never>
        Returns: number
      }
      initialize_daily_goals_for_today: {
        Args: Record<string, never>
        Returns: void
      }
      current_date_cambodia: {
        Args: Record<string, never>
        Returns: string
      }
    }
    Enums: {
      [_ in never]: never
    }
  }
}
