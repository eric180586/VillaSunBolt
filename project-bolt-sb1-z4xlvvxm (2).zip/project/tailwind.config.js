/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        beige: {
          50: '#fdfbf7',
          100: '#f9f5ed',
          200: '#f3ead5',
          300: '#e8d9b8',
          400: '#d9c299',
          500: '#c9ab7a',
          600: '#b8945b',
          700: '#9a7a49',
          800: '#7c6139',
          900: '#5e4a2b',
        },
      },
    },
  },
  plugins: [],
};
