# VillaSun App - Vercel Deployment Anleitung

## Schnelle Lösung für den aktuellen Fehler

Der Fehler "Could not read package.json" bedeutet, dass Vercel die Dateien nicht im richtigen Verzeichnis findet.

### ✅ LÖSUNG 1: Vercel Settings anpassen

1. Gehen Sie zu https://vercel.com/dashboard
2. Öffnen Sie Ihr Projekt
3. Gehen Sie zu **Settings** → **General**
4. Bei **Root Directory** tragen Sie ein: `.` (nur ein Punkt)
5. Klicken Sie auf **Save**
6. Gehen Sie zu **Deployments** → Klicken Sie auf die drei Punkte beim letzten Deployment → **Redeploy**

### ✅ LÖSUNG 2: GitHub Repository neu verbinden

1. Löschen Sie das aktuelle Vercel Projekt (Settings → Advanced → Delete)
2. Erstellen Sie ein neues Projekt
3. Wählen Sie **Import Git Repository**
4. Wählen Sie `eric180586/Villa-Sun`
5. **Framework Preset:** Vite
6. **Root Directory:** `.` (leer lassen oder nur Punkt)
7. **Build Command:** `npm run build`
8. **Output Directory:** `dist`

### Environment Variables (WICHTIG!)

Fügen Sie diese Variablen hinzu:

```
VITE_SUPABASE_URL=https://thncdxvoubtsimwvsigi.supabase.co
VITE_SUPABASE_ANON_KEY=[Ihr Key aus .env]
VITE_VAPID_PUBLIC_KEY=[Ihr Key aus .env]
```

## Dateien die hinzugefügt wurden

- `vercel.json` - Vercel Konfiguration
- `.vercelignore` - Dateien die ignoriert werden sollen
- `.github/workflows/vercel-deploy.yml` - Automatisches Deployment (optional)

## Nach dem Deployment

1. Öffnen Sie die Vercel URL
2. Testen Sie den Login
3. Prüfen Sie die Browser Console (F12) auf Fehler
4. Wenn alles funktioniert: ✅ Fertig!
5. Wenn Fehler: Schicken Sie Screenshot der Console
