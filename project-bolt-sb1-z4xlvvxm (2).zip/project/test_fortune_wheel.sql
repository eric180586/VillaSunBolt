-- ============================================================================
-- FORTUNE WHEEL - TEST & DEBUGGING QUERIES
-- ============================================================================
-- Use these queries in Supabase SQL Editor to test and debug the fortune wheel

-- ============================================================================
-- 1. CHECK FOR DUPLICATE SPINS (Main Problem #1)
-- ============================================================================
-- This should return EMPTY after fix
SELECT
  p.full_name,
  fws.user_id,
  fws.spin_date,
  COUNT(*) as spin_count,
  array_agg(fws.reward_label ORDER BY fws.created_at) as rewards,
  array_agg(fws.created_at ORDER BY fws.created_at) as spin_times
FROM fortune_wheel_spins fws
JOIN profiles p ON fws.user_id = p.id
GROUP BY p.full_name, fws.user_id, fws.spin_date
HAVING COUNT(*) > 1
ORDER BY fws.spin_date DESC;

-- ============================================================================
-- 2. VIEW TODAY'S SPINS
-- ============================================================================
SELECT
  p.full_name,
  p.role,
  fws.spin_date,
  fws.reward_label,
  fws.reward_value,
  fws.created_at,
  ci.check_in_time,
  ci.shift_type,
  ci.status as check_in_status
FROM fortune_wheel_spins fws
JOIN profiles p ON fws.user_id = p.id
LEFT JOIN check_ins ci ON fws.check_in_id = ci.id
WHERE fws.spin_date = CURRENT_DATE
ORDER BY fws.created_at DESC;

-- ============================================================================
-- 3. CHECK IF POINTS WERE ADDED (Main Problem #2)
-- ============================================================================
SELECT
  p.full_name,
  ph.points_change,
  ph.reason,
  ph.category,
  ph.created_at
FROM points_history ph
JOIN profiles p ON ph.user_id = p.id
WHERE
  (ph.reason ILIKE '%Glücksrad%' OR ph.reason ILIKE '%Fortune%')
  AND DATE(ph.created_at AT TIME ZONE 'Asia/Phnom_Penh') = CURRENT_DATE
ORDER BY ph.created_at DESC;

-- ============================================================================
-- 4. VERIFY DAILY POINTS UPDATED
-- ============================================================================
SELECT
  p.full_name,
  dpg.goal_date,
  dpg.achieved_points,
  dpg.theoretically_achievable_points,
  dpg.percentage,
  dpg.updated_at
FROM daily_point_goals dpg
JOIN profiles p ON dpg.user_id = p.id
WHERE dpg.goal_date = CURRENT_DATE
ORDER BY dpg.updated_at DESC;

-- ============================================================================
-- 5. CROSS-CHECK: Spins vs Points History
-- ============================================================================
-- Shows which spins have matching points entries
SELECT
  p.full_name,
  fws.spin_date,
  fws.reward_label,
  fws.reward_value,
  fws.created_at as spin_time,
  ph.points_change,
  ph.created_at as points_time,
  CASE
    WHEN ph.id IS NULL THEN '❌ NO POINTS ENTRY'
    WHEN ph.points_change = 0 THEN '✓ 0 Points (correct)'
    WHEN ph.points_change = -4 THEN '✓ -4 Points (malus)'
    WHEN ph.points_change = 5 THEN '✓ +5 Points (bonus)'
    ELSE '⚠️ Unexpected value'
  END as status
FROM fortune_wheel_spins fws
JOIN profiles p ON fws.user_id = p.id
LEFT JOIN points_history ph ON
  ph.user_id = fws.user_id
  AND DATE(ph.created_at AT TIME ZONE 'Asia/Phnom_Penh') = fws.spin_date
  AND ph.category = 'bonus'
WHERE fws.spin_date = CURRENT_DATE
ORDER BY fws.created_at DESC;

-- ============================================================================
-- 6. CLEAN UP DUPLICATES (ONLY IF NEEDED!)
-- ============================================================================
-- ⚠️ WARNING: This will DELETE duplicate spins, keeping only the oldest one
-- Run Query #1 first to confirm duplicates exist before running this!

-- Uncomment to execute:
/*
WITH ranked_spins AS (
  SELECT
    id,
    user_id,
    spin_date,
    created_at,
    ROW_NUMBER() OVER (
      PARTITION BY user_id, spin_date
      ORDER BY created_at ASC
    ) as rn
  FROM fortune_wheel_spins
)
DELETE FROM fortune_wheel_spins
WHERE id IN (
  SELECT id FROM ranked_spins WHERE rn > 1
);
*/

-- ============================================================================
-- 7. VIEW SPECIFIC USER'S FORTUNE WHEEL HISTORY
-- ============================================================================
-- Replace <user_id> with actual UUID
/*
SELECT
  fws.spin_date,
  fws.reward_label,
  fws.reward_value,
  fws.created_at,
  ci.check_in_time,
  ci.shift_type,
  ph.points_change as actual_points_added
FROM fortune_wheel_spins fws
LEFT JOIN check_ins ci ON fws.check_in_id = ci.id
LEFT JOIN points_history ph ON
  ph.user_id = fws.user_id
  AND DATE(ph.created_at AT TIME ZONE 'Asia/Phnom_Penh') = fws.spin_date
  AND ph.category = 'bonus'
WHERE fws.user_id = '<user_id>'::uuid
ORDER BY fws.spin_date DESC, fws.created_at DESC;
*/

-- ============================================================================
-- 8. CHECK IF USER CAN SPIN TODAY
-- ============================================================================
-- Replace <user_id> with actual UUID
-- This is what the frontend checks
/*
SELECT
  CASE
    WHEN EXISTS (
      SELECT 1 FROM fortune_wheel_spins
      WHERE user_id = '<user_id>'::uuid
      AND spin_date = CURRENT_DATE
    )
    THEN '❌ Already spun today'
    WHEN EXISTS (
      SELECT 1 FROM check_ins
      WHERE user_id = '<user_id>'::uuid
      AND check_in_date = CURRENT_DATE
      AND status = 'approved'
    )
    THEN '✅ Can spin (has approved check-in)'
    ELSE '⏳ Waiting for check-in approval'
  END as wheel_status;
*/

-- ============================================================================
-- 9. TEST add_bonus_points FUNCTION
-- ============================================================================
-- Replace <user_id> with actual UUID
-- This tests the points awarding directly
/*
SELECT add_bonus_points(
  '<user_id>'::uuid,
  5,
  'Test Fortune Wheel Bonus'
);

-- Then verify:
SELECT * FROM points_history
WHERE user_id = '<user_id>'::uuid
ORDER BY created_at DESC
LIMIT 1;
*/

-- ============================================================================
-- 10. STATISTICS: Fortune Wheel Usage
-- ============================================================================
SELECT
  DATE(fws.spin_date) as date,
  COUNT(DISTINCT fws.user_id) as unique_spinners,
  COUNT(*) as total_spins,
  SUM(CASE WHEN fws.reward_value = 1 THEN 1 ELSE 0 END) as malus_spins,
  SUM(CASE WHEN fws.reward_value = 5 THEN 1 ELSE 0 END) as neutral_spins,
  SUM(CASE WHEN fws.reward_value = 10 THEN 1 ELSE 0 END) as bonus_spins,
  ROUND(AVG(fws.reward_value), 2) as avg_reward
FROM fortune_wheel_spins fws
WHERE fws.spin_date >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY DATE(fws.spin_date)
ORDER BY DATE(fws.spin_date) DESC;

-- ============================================================================
-- 11. CHECK FOR ORPHANED SPINS (spins without check-ins)
-- ============================================================================
-- Should be empty - every spin must have a check-in
SELECT
  p.full_name,
  fws.spin_date,
  fws.reward_label,
  fws.created_at,
  fws.check_in_id
FROM fortune_wheel_spins fws
JOIN profiles p ON fws.user_id = p.id
LEFT JOIN check_ins ci ON fws.check_in_id = ci.id
WHERE ci.id IS NULL
ORDER BY fws.created_at DESC;

-- ============================================================================
-- 12. PERFORMANCE CHECK: Index Usage
-- ============================================================================
SELECT
  schemaname,
  tablename,
  indexname,
  idx_scan as times_used,
  idx_tup_read as tuples_read,
  idx_tup_fetch as tuples_fetched
FROM pg_stat_user_indexes
WHERE tablename = 'fortune_wheel_spins'
ORDER BY idx_scan DESC;

-- ============================================================================
-- QUICK REFERENCE: Expected Values
-- ============================================================================
/*
FORTUNE WHEEL SEGMENTS:
┌─────────┬──────────────┬─────────────┬──────────────────┐
│ Segment │ reward_label │ reward_val  │ actual_points    │
├─────────┼──────────────┼─────────────┼──────────────────┤
│    1    │ "1 Punkt"    │      1      │       -4         │ ← Malus!
│   2-9   │ "5 Punkte"   │      5      │        0         │ ← No change
│   10    │ "10 Punkte"  │     10      │       +5         │ ← Bonus!
└─────────┴──────────────┴─────────────┴──────────────────┘

POINTS LOGIC:
- reward_value: What is SHOWN to user
- actual_points: What is ACTUALLY added to profile.points
- Why different? Game design - not all segments add real points
*/
